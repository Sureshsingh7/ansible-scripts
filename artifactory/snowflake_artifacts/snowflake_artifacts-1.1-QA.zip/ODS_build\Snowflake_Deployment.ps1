param(
[String] $configFile,
[String] $basePath,
[String] $env,
[String] $outputPath,
[String] $accountName
)
Write-Host "configfile path is $configFile"
Write-Host "replace dir with $basePath"
Write-Host "environment is $env"
Write-Host "environment is $outputPath"
Write-Host "environment is $accountName"
cd E:\a
